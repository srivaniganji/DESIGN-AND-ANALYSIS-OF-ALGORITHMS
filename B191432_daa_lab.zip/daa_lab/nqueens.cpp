#include<iostream>
using namespace std;
void print(int n,int board[])
{
    for(int i=0;i<n;i++)
    {
        cout<<board[i]<<" ";
    }
    cout<<endl;
    return;
}
int isSafe(int board[],int index,int val)
{
    for(int i=0;i<index;i++)
    {
        if(board[i]==val || abs(index-i)==abs(val-board[i]))
            return 0;
    }
    return 1;
}
void nQueens(int n,int board[],int k)
{
    if(k==n)
    {
        print(n,board);
        return;
    }
    for(int i=0;i<n;i++)
    {
        if(isSafe(board,k,i+1))
        {
            board[k]=i+1;
            nQueens(n,board,k+1);
        }
    }
}
int main()
{
    int n;
    cin>>n;
    int board[n];
    for(int i=0;i<n;i++)
    {
        board[i]=i+1;
    }
    cout<<"The possible ways of placing "<<n<<" Queens on the Chessboard:"<<endl;
    nQueens(n,board,0);
    return 0;
}