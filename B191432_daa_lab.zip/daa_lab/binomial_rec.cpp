/*
#include<iostream>
using namespace std;
int binomialCoefficient(int n,int k)
{
    if(k==0 || n==k)
        return 1;
    return binomialCoefficient(n-1,k-1)+binomialCoefficient(n-1,k);
}
int main()
{
    int n;
    cin>>n;
    int k;
    cin>>k;
    cout<<binomialCoefficient(n,k);
    return 0;
}

//Memorisation
#include<iostream>
#include<vector>
using namespace std;
int nCr(int n,int r,vector<vector<int>>dp)
{
    if(dp[n][r]!=-1)
        return dp[n][r];
    if(r==0 || n==r)
        return dp[n][r]=1;
    return dp[n][r]=nCr(n-1,r-1,dp)+nCr(n-1,r,dp);
}
int main()
{
    int n;
    cin>>n;
    int r;
    cin>>r;
    vector<vector<int>>dp(n+1,vector<int>(r+1,-1));
    cout<<nCr(n,r,dp);
    return 0;
}
*/
#include<iostream>
#include<vector>
using namespace std;
int binomialCoefficient(int n,int r)
{
    vector<vector<int>>dp(n+1,vector<int>(r+1,-1));
    for(int i=0;i<=n;i++)
    {
        for(int j=0;j<=r;j++)
        {
            if(j==0 || i==j)
            {
                dp[i][j]=1;
                continue;
            }
            dp[i][j]=dp[i-1][j]+dp[i-1][j-1];
        }
    }
    return dp[n][r];
}
int main()
{
    int n;
    cin>>n;
    int k;
    cin>>k;
    cout<<binomialCoefficient(n,k);
    return 0;
}