#include<iostream>
#include<vector>
using namespace std;
bool subsetSum(int n,int arr[],int s,vector<vector<int>>dp)
{
    if(dp[n][s]!=-1)
        return dp[n][s];
    if(n==0)
        return dp[n][s]=0;
    if(s==0)
        return dp[n][s]=1;
    if(arr[n-1]<=s)
        return dp[n][s]=(subsetSum(n-1,arr,s-arr[n-1],dp) || subsetSum(n-1,arr,s,dp));
    return dp[n][s]=subsetSum(n-1,arr,s,dp);
}
int main()
{
    int n;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    int sum;
    cin>>sum;
    vector<vector<int>>dp(n+1,vector<int>(sum+1,-1));
    bool flag=subsetSum(n,arr,sum,dp);
    if(flag)
        cout<<"Subset Sum possible!"<<endl;
    else 
        cout<<"Subset Sum not Possible!"<<endl;
    return 0;
}