#include<iostream>
#include<vector>
using namespace std;
int countSubsets(int n,int arr[],int s)
{
    vector<vector<int>>dp(n+1,vector<int>(s+1,-1));
    for(int i=0;i<=n;i++)
    {
        for(int j=0;j<=s;j++)
        {
            if(i==0)
            {
                dp[i][j]=0;
                continue;
            }
            if(j==0)
            {
                dp[i][j]=1;
                continue;
            }
            if(arr[i-1]<=j)
                dp[i][j]=dp[i-1][j-arr[i-1]]+dp[i-1][j];
            else 
                dp[i][j]=dp[i-1][j];
        }
    }
    return dp[n][s];
}
int main()
{
    int n;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    int s;
    cin>>s;
    int count=countSubsets(n,arr,s);
    cout<<"Total number of Subsets possible for given sum = "<<count<<endl;
    return 0;
}