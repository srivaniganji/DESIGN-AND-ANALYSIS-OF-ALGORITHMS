#include<bits/stdc++.h>
#include<algorithm>
#include<math.h>
using namespace std;
struct point
{
    int x;
    int y;
};
bool sortbysec(struct point a,struct point b)
{
    return ((a.y)<(b.y));
}
/*
bool sortbyY(struct point a,struct point b)
{
    return ((a.y)<(b.y));
}
*/
double distance(struct point a,struct point b)
{
    return sqrt((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y));
}
double bruteForce(struct point p[],int s,int e)
{
    double mini=INT_MAX;
    for(int i=s;i<e-1;i++)
    {
        for(int j=i+1;j<e;j++)
        {
            mini=min(mini,distance(p[i],p[j]));
        }
    }
    return mini;
}
double stripMin(struct point strip[],int s,int e,double d)
{
    sort(strip,strip+e,sortbysec());
    for(int i=s;i<e;i++)
    {
        for(int j=i+1;j<e;j++)
        {
            if(strip[j].y-strip[i].y<d)
            {
                double ds=distance(strip[i],strip[j]);
                d=min(ds,d);
            }
        }
    }
    return d;
}
double closestPair(struct point p[],int st,int end)
{
    sort(p,p+end);
    if(end-st<=3)
        return bruteForce(p,st,end);
    int mid=(st+end)/2;
    int dl=closestPair(p,st,mid);
    int dr=closestPair(p,mid+1,end);
    double d=min(dl,dr);
    struct point strip[100];
    int j=0;
    for(int i=0;i<end;i++)
    {
        if(abs(p[i].x-p[mid].x))
            strip[j++]=p[i];
    }
    return min(d,stripMin(strip,0,j,d));
}
int main()
{
    int n;
    cin>>n;
    struct point p[n];
    for(int i=0;i<n;i++)
    {
        cin>>p[i].x>>p[i].y;
    }
    double min_distance=closestPair(p,0,n);
    cout<<"Closest Pair Distance = "<<min_distance<<endl;
    return 0;
}