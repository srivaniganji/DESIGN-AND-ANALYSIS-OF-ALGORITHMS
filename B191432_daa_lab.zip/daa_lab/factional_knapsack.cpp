#include<iostream>
#include<algorithm>
using namespace std;
struct item
{
    int weight;
    int profit;
};
int cmp(struct item a,struct item b)
{
    double x=(double)a.profit/a.weight;
    double y=(double)b.profit/b.weight;
    return x>y;
}
double fractionalKnapsack(int n,struct item it[],int w)
{
    sort(it,it+n,cmp);
    double res=0;
    for(int i=0;i<n;i++)
    {
        if(it[i].weight<=w)
        {
            w-=it[i].weight;
            res+=it[i].profit;
        }
        else 
        {
            res+=((double)it[i].profit/it[i].weight)*w;
            break;
        }
    }
    return res;
}
int main()
{
    int n;
    cin>>n;
    struct item it[n];
    for(int i=0;i<n;i++)
    {
        cin>>it[i].weight>>it[i].profit;
    }
    int w;
    cin>>w;
    double totalProfit=fractionalKnapsack(n,it,w);
    cout<<"Max Profit = "<<totalProfit<<endl;
    return 0;
}

/*
5
10 100
3 20
2 35
7 90
11 140
20
*/