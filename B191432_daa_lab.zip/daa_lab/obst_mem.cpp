#include<iostream>
#include<vector>
#include<climits>
using namespace std;
int sum(int freq[],int i,int j)
{
    int s=0;
    for(int k=i;k<=j;k++)
    {
        s+=freq[k];
    }
    return s;
}
int obst(int i,int j,int keys[],int freq[],vector<vector<int>>dp)
{
    
    if(j<i)
        return dp[i][j]=0;
    if(i==j)
        return dp[i][j]=freq[i];
        if(dp[i][j]!=-1)
        return dp[i][j];
    int mini=INT_MAX;
    for(int k=i;k<=j;k++)
    {
        int val=obst(i,k-1,keys,freq,dp)+obst(k+1,j,keys,freq,dp);
        if(val<mini)
        {
            mini=val;
            //dp[i][j]=mini;
        }
    }
    
    return dp[i][j]=mini+sum(freq,i,j);
}
int main()
{
    int n;
    cin>>n;
    int keys[n];
    for(int i=0;i<n;i++)
    {
        cin>>keys[i];
    }
    int freq[n];
    for(int i=0;i<n;i++)
    {
        cin>>freq[i];
    }
    vector<vector<int>>dp(n+1,vector<int>(n+1,-1));
    cout<<"Optimal cost of retrieving the keys = "<<obst(0,n-1,keys,freq,dp)<<endl;
    return 0;
}