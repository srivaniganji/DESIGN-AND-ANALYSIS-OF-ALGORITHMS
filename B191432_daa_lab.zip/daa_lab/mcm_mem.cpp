#include<iostream>
#include<vector>
#include<climits>
using namespace std;
int mcm(int a[],int i,int j,vector<vector<int>>dp)
{
    if(dp[i][j]!=-1)
        return dp[i][j];
    if(i==j)
        return dp[i][j]=0;
    int mini=INT_MAX;
    for(int k=i;k<j;k++)
    {
        int val=mcm(a,i,k,dp)+mcm(a,k+1,j,dp)+a[i-1]*a[j]*a[k];
        mini=min(mini,val);
    }
    return dp[i][j]=mini;
}
int main()
{
    int n;
    cin>>n;
    int size=n+1;
    int a[size];
    for(int i=0;i<size;i++)
    {
        cin>>a[i];
    }
    vector<vector<int>>dp(n+1,vector<int>(n+1,-1));
    cout<<mcm(a,1,n,dp)<<endl;
    return 0;
}