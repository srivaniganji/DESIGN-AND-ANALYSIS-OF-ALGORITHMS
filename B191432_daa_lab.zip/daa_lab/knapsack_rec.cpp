#include<iostream>
using namespace std;
int knapsack(int n,int wt[],int val[],int w)
{
    if(n==0 || w==0)
        return 0;
    if(wt[n-1]<=w)
        return max(val[n-1]+knapsack(n-1,wt,val,w-wt[n-1]),knapsack(n-1,wt,val,w));
    return knapsack(n-1,wt,val,w);
}
int main()
{
    int n;
    cin>>n;
    int val[n];
    int wt[n];
    for(int i=0;i<n;i++)
    {
        cin>>wt[i];
    }
    for(int i=0;i<n;i++)
    {
        cin>>val[i];
    }
    int w;
    cin>>w;
    int profit=knapsack(n,wt,val,w);
    cout<<"Profit = "<<profit<<endl;
    return 0;

}
/*
val[] = { 60, 100, 120 };
weight[] = { 10, 20, 30 };
W = 50;
Profit=220
*/