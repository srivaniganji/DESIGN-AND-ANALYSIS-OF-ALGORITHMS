#include<iostream>
#include<vector>
using namespace std;
void print(int arr[],int n)
{
	for(int i=0;i<n;i++)
	{
		cout<<arr[i]<<" ";
	}
	cout<<endl;
}
int isSafe(int n,int index,int val,int graph[][4],int arr[])
{
	if(index==n-1) 
	{
		for(int i=0;i<index;i++)
		{
			if(arr[i]==val || graph[arr[index-1]][val]==0 || graph[arr[0]][val]==0)
				return 0;
		}
	}
	else
	{
		for(int i=0;i<index;i++)
		{
			if(arr[i]==val || graph[arr[index-1]][val]==0)
				return 0;
		}
	}
	
	return 1;
}
void hamiltonian(int n,int k,int graph[][4],int arr[])
{
	arr[0]=0;
	if(k==n)
	{
		print(arr,n);
		return;
	}
	for(int i=0;i<n;i++)
	{
		if(isSafe(n,k,i,graph,arr))
		{
			arr[k]=i;
			hamiltonian(n,k+1,graph,arr);
		}
	}
}
int main()
{
	int n=4;
	//int graph[5][5]={{0,1,0,1,0},{1,0,1,1,1},{0,1,0,0,1},{1,1,0,0,1},{0,1,1,1,0}};
	int graph[4][4]={{0,1,1,4},{1,0,2,2},{1,2,0,3},{4,2,3,0}};
	int arr[n];
	hamiltonian(n,1,graph,arr);
	return 0;
}
