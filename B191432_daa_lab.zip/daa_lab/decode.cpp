#include<iostream>
using namespace std;
char vowel(char c)
{
    if(c=='a')
        return '1';
    if(c=='e')
        return '2';
    if(c=='i')
        return '3';
    if(c=='o')
        return '4';
    if(c=='u')
        return '5';
    return c;
}
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n;
        cin>>n;
        string s;
        cin>>s;
        string ans="";
        for(int i=0;i<n;i++)
        {
            char k=vowel(s[i]);
            if(k!=s[i])
            {
                ans+=k;
            }
            else 
            {
                s[i]++;
                k=vowel(s[i]);
                ans+=k;
            }
        }
        cout<<ans<<endl;
    }
    return 0;
}