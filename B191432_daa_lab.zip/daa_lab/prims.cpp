#include<iostream>
#include<vector>
#include<climits>
using namespace std;
int prims(int n,vector<vector<int> >adj,vector<int>visited,int total)
{
	visited[0]=1;
	int u,v;
	for(int k=1;k<n;k++)
	{
		int mini=INT_MAX;
		for(int i=0;i<n;i++)
		{
			if(visited[i]==1)
			{
				for(int j=0;j<n;j++)
				{
					if(visited[j]!=1 && adj[i][j]!=0)
					{
						if(adj[i][j]<mini)
						{
							mini=adj[i][j];
							u=i;
							v=j;
						}
					}
				}
			}
		}
		cout<<u<<" "<<v<<" "<<adj[u][v]<<endl;
		total+=adj[u][v];
		visited[v]=1;
	}
	return total;
}
int main()
{
	int n;
	cout<<"Enter no. of nodes: ";
	cin>>n;
	int e;
	cout<<"Enter no. of edges: ";
	cin>>e;
	vector<vector<int> >adj(n,vector<int>(n,0));
	/*
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			adj[i][j]=0;
		}
	}	
	*/
	int x,y,cost;
	cout<<"Enter edges:"<<endl;
	for(int i=0;i<e;i++)
	{
		cin>>x>>y>>cost;
		adj[x][y]=cost;
		adj[y][x]=cost;
	}
	cout<<"Adjacency Matrix: "<<endl;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cout<<adj[i][j]<<" ";
		}
		cout<<endl;
	}
	vector<int>visited(n,-1);
	int total=0;
	cout<<"Minimal cost of spanning tree = "<<prims(n,adj,visited,total)<<endl;
	return 0;
}








