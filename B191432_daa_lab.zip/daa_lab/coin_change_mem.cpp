#include<iostream>
#include<vector>
using namespace std;
int minimumCoins(int n,int coins[],int s,vector<vector<int>>dp)
{
    if(dp[n][s]!=-1)
        return dp[n][s];
    if(n==0)
        return dp[n][s]=9999999;
    if(s==0)
        return dp[n][s]=0;
    if(coins[n-1]<=s)
        return dp[n][s]=min(1+minimumCoins(n,coins,s-coins[n-1],dp),minimumCoins(n-1,coins,s,dp));
    return dp[n][s]=minimumCoins(n-1,coins,s,dp);
}
int main()
{
    int n;
    cin>>n;
    int coins[n];
    for(int i=0;i<n;i++)
    {
        cin>>coins[i];
    }
    int s;
    cin>>s;
    vector<vector<int>>dp(n+1,vector<int>(s+1,-1));
    int min_coins=minimumCoins(n,coins,s,dp);
    cout<<"Minimum number of coins required = "<<min_coins<<endl;
    return 0;
}