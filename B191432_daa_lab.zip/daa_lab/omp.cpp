#include<iostream>
#include<climits>
using namespace std;
int findMin(int n,int arr[])
{
    int mini=0;
    for(int i=1;i<n;i++)
    {
        if(arr[i]<arr[mini])
            mini=i;
    }
    return mini;
}
int omp(int n,int arr[])
{
    int sum=0;
    while(n>1)
    {
        int i=findMin(n,arr);
        swap(arr[i],arr[n-1]);
        i=findMin(n-1,arr);
        swap(arr[i],arr[n-2]);
        sum+=arr[n-1]+arr[n-2];
        arr[n-2]=arr[n-1]+arr[n-2];
        n--;
    }
    return sum;
}

/*
void minHeap(int arr[],int n,int i)
{
    int smallest=i;
    int left=2*i+1;
    int right=2*i+2;
    if(left<n && arr[left]<arr[smallest])
        smallest=left;
    if(right<n && arr[right]<arr[smallest])
        smallest=right;
    if(smallest!=i)
    {
        swap(arr[i],arr[smallest]);
        minHeap(arr,n,smallest);
    }
}
int omp(int n,int arr[])
{
    int sum=0;
    while(n>1)
    {
        minHeap(arr,n,0);
        int min1=arr[n-1];
        n--;
        minHeap(arr,n,0);
        int min2=arr[n-1];
        arr[n-1]=min1+min2;
        sum+=min1+min2;
    }
}
*/
int main()
{
    int n;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    cout<<omp(n,arr)<<endl;
    return 0;
}