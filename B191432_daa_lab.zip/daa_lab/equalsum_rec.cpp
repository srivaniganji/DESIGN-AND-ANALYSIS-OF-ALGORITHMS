#include<iostream>
using namespace std;
int isSubsetSum(int n,int arr[],int s)
{
    if(n==0)
        return 0;
    if(s==0)
        return 1;
    if(arr[n-1]<=s)
        return (isSubsetSum(n,arr,s-arr[n-1]) || isSubsetSum(n-1,arr,s));
    return isSubsetSum(n-1,arr,s);
}
int main()
{
    int n;
    cout<<"enter size:";
    cin>>n;
    int arr[n];
    int sum=0;
    cout<<"enter elements: ";
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
        sum+=arr[i];
    }
    cout<<endl;
    int flag=-1;
    if(sum%2!=0)
        flag=0;
    else 
        flag=isSubsetSum(n,arr,sum/2);
    if(flag)
        cout<<"Equal Sum Partition Possible!"<<endl;
    else    
        cout<<"Equal Sum Partition not possible!"<<endl;
    return 0;
}
