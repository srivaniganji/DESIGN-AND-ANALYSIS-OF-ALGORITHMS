#include<iostream>
#include<vector>
using namespace std;
struct point
{
    int x;
    int y;
};
int main()
{
    int n;
    cin>>n;
    struct point p[n];
    vector<struct point>ans;
    for(int i=0;i<n;i++)
    {
        cin>>p[i].x>>p[i].y;
    }
    cout<<endl;
    int a,b,c;
    for(int i=0;i<n-1;i++)
    {
        for(int j=i;j<n;j++)
        {
            a=p[j].y-p[i].y;
            b=p[j].x-p[i].x;
            c=p[i].x*p[j].y-p[j].x*p[i].y;
            int flag=1;
            for(int k=0;k<n;k++)
            {
                if(k!=i && k!=j)
                {
                    if(a*p[k].x+b*p[k].y<c)
                        flag=0;
                        //left++;
                    //else if(a*p[k].x+b*p[k].y>c)
                        //right++;
                }
            }
            if(flag)
            {
                ans.push_back(p[j]);
                ans.push_back(p[i]);
            }
            /*
            if(left==n-2 || right==n-2)
            {
                ans.push_back(p[j]);
                ans.push_back(p[i]);
            }
            */
        }
    }
    for(int i=0;i<ans.size();i++)
    {
        cout<<ans[i].x<<" "<<ans[i].y<<endl;
    }
    cout<<endl;
    return 0;
}

/*
6
0 0
0 4
-4 0
5 0
0 -6
1 0

-4 0
5 0
0 -6
0 4


10
0 0
1 -4
-1 -1
-5 -3
-3 -1
-1 -3
-2 -2
-1 -1
-2 -1
-1 1
1 -4
0 0
-1 -3
0 0
-5 -3
1 -4
-3 -1
1 -4
-1 -3
1 -4
-2 -2
1 -4
-2 -1
1 -4
-1 -1
-1 -1
-1 -3
-5 -3
-2 -2
-5 -3
-1 -1
-5 -3
-1 -3
-3 -1
-2 -2
-3 -1
-1 -1
-3 -1
-2 -1
-3 -1
-2 -2
-1 -3
-1 -1
-2 -2
*/