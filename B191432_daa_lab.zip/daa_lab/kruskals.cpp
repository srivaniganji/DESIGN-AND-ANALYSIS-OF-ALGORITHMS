#include<iostream>
#include<vector>
#include<climits>
using namespace std;
int findMin(int n,vector<vector<int> >adj,int &u,int &v)
{
	int mini=INT_MAX;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			if(adj[i][j]<mini && adj[i][j]!=0)
			{
				mini=adj[i][j];
				u=i;
				v=j;
			}
		}
	}
	return mini;
}
int findParent(vector<int>p,int i)
{
	while(p[i]!=-1)
	{
		i=p[i];
	}
	return i;
}
int kruskal(int n,vector<vector<int> >adj,vector<int>parent)
{
	int cost=0;
	int u,v;
	for(int k=0;k<=n;k++)
	{
		int x=findMin(n,adj,u,v);
		int pu=findParent(parent,u);
		int pv=findParent(parent,v);
		if(pu!=pv)
		{
			parent[pv]=pu;
			cout<<u<<" "<<v<<" "<<endl;
			cost+=x;
		}
		adj[u][v]=0;
		adj[u][v]=0;
	}
	return cost;
}
int main()
{
	int n;
	cout<<"Enter no. of nodes: ";
	cin>>n;
	int e;
	cout<<"Enter no. of edges: ";
	cin>>e;
	vector<vector<int> >adj(n,vector<int>(n,0));
	int x,y,z;
	for(int i=0;i<e;i++)
	{
		cin>>x>>y>>z;
		adj[x][y]=z;
		adj[y][x]=z;
	}
	//vector<int>visited(n,-1);
	vector<int>parent(n,-1);
	cout<<"Minimal spanning tree: "<<endl;
	int total=kruskal(n,adj,parent);
	cout<<total<<endl;
	return 0;
}

/*
Enter no. of nodes: 6
Enter no. of edges: 8
0 1 3
1 2 5
2 3 6
3 4 4 
4 5 2
5 0 7
1 4 8
2 5 4
Minimal spanning tree: 
4 5
0 1
2 5
3 4
13
*/



