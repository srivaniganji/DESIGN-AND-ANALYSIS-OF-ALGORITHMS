#include<iostream>
#include<vector>
using namespace std;
int countSubsets(int n,int arr[],int s,vector<vector<int>>dp)
{
    if(dp[n][s]!=-1)
        return dp[n][s];
    if(n==0)
        return dp[n][s]=0;
    if(s==0)
        return dp[n][s]=1;
    if(arr[n-1]<=s)
        return dp[n][s]=countSubsets(n,arr,s-arr[n-1],dp)+countSubsets(n-1,arr,s,dp);
    return dp[n][s]=countSubsets(n-1,arr,s,dp);
}
int main()
{
    int n;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    int s;
    cin>>s;
    vector<vector<int>>dp(n+1,vector<int>(s+1,-1));
    int count=countSubsets(n,arr,s,dp);
    cout<<"Total number of Subsets possible for given sum = "<<count<<endl;
    return 0;
}