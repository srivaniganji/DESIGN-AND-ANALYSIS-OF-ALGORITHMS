#include<iostream>
using namespace std;
bool subsetSum(int arr[],int n,int s)
{
    if(s==0)
        return true;
    if(n==0)
        return false;
    if(arr[n-1]<=s)
        return (subsetSum(arr,n-1,s-arr[n-1]) || subsetSum(arr,n-1,s));
    return subsetSum(arr,n-1,s);
}
int main()
{
    int n;
    cout<<"size: ";
    cin>>n;
    int arr[n];
    cout<<"enter elements: ";
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    int sum;
    cout<<"sum: ";
    cin>>sum;
    bool flag=subsetSum(arr,n,sum);
    if(flag)
        cout<<"Subset Sum Possible!"<<endl;
    else 
        cout<<"Subset Sum not Possible!"<<endl;
    return 0;
}
