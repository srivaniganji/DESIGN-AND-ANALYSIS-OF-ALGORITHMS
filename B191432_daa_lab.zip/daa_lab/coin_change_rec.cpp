#include<iostream>
#include<climits>
using namespace std;
int minimumCoins(int n,int coins[],int s)
{
    if(n==0)
        return 99999;
    if(s==0)
        return 0;
    if(coins[n-1]<=s)
        return min(1+minimumCoins(n,coins,s-coins[n-1]),minimumCoins(n-1,coins,s));
    return minimumCoins(n-1,coins,s);
}
int main()
{
    int n;
    cin>>n;
    int coins[n];
    for(int i=0;i<n;i++)
    {
        cin>>coins[i];
    }
    int s;
    cin>>s;
    int min_coins=minimumCoins(n,coins,s);
    cout<<"Minimum number of coins required = "<<min_coins<<endl;
    return 0;
}