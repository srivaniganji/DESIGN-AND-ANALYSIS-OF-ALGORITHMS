#include<iostream>
using namespace std;
void print(int arr[],int n)
{
    for(int i=0;i<n;i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}
void permutations(int arr[],int n,int k)
{
    if(k==n)
    {
        print(arr,n);
        return;
    }
    for(int i=0;i<2;i++)
    {
        arr[k]=i;
        permutations(arr,n,k+1);
    }
}
int main()
{
    int n;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++)
    {
        arr[i]=i+1;
    }
    cout<<"Binary permutations: "<<endl;
    permutations(arr,n,0);
    return 0;
}