#include<iostream>
#include<climits>
using namespace std;
int mcm(int a[],int i,int j)
{
    if(i==j)
        return 0;
    int mini=INT_MAX;
    for(int k=i;k<j;k++)
    {
        int val=mcm(a,i,k)+mcm(a,k+1,j)+a[i-1]*a[k]*a[j];
        mini=min(val,mini);
    }
    return mini;
}
int main()
{
    int n;
    cout<<"Enter number of matrices: ";
    cin>>n;
    int size=n+1;
    int a[size];
    for(int i=0;i<size;i++)
    {
        cin>>a[i];
    }
    cout<<mcm(a,1,n)<<endl;
}