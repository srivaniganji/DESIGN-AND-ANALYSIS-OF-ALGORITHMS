#include<iostream>
#include<map>
using namespace std;
struct node
{
    int data;
    struct node* next;
};
struct node *createNode(int x)
{
    struct node *nn=(struct node*)malloc(sizeof(struct node));
    nn->data=x;
    nn->next=NULL;
    return nn;
}
void deleteDuplicates(struct node* temp)
{
    map<int,int>mp;
    struct node* prev;
    while(temp)
    {
        mp[temp->data]++;
        if(mp[temp->data]>1)
        {
            prev->next=temp->next;
        }
        else 
        {
            prev=temp;
        }
        temp=temp->next;
    }
}
void printLL(struct node* temp)
{
    while(temp)
    {
        cout<<temp->data<<" ";
        temp=temp->next;
    }
    cout<<endl;
}
int main()
{
    struct node* head=NULL;
    head=createNode(1);
    head->next=createNode(2);
    struct node* temp=head;
    temp=temp->next;
    temp->next=createNode(2);
    temp=temp->next;
    temp->next=createNode(3);
    printLL(head);
    deleteDuplicates(head);
    printLL(head);
    return 0;
}