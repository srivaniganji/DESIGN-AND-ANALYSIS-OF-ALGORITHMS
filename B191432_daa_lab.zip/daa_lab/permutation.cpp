#include<iostream>
using namespace std;
void print(int n,int a[])
{
    for(int i=0;i<n;i++)
    {
        cout<<a[i];
    }
    cout<<endl;
}
bool isSafe(int a[],int k,int val)
{
    for(int i=0;i<k;i++)
    {
        if(a[i]==val)
            return 0;
    }
    return 1;
}
int repeatedPermutation(int n,int a[],int k)
{
    if(k==n)
    {
        print(n,a);
        return 0;
    }
    for(int i=0;i<n;i++)
    {
        a[k]=i+1;
        repeatedPermutation(n,a,k+1);
    }
    return 0;
}
int permutation(int n,int a[],int k)
{
    if(k==n)
    {
        print(n,a);
        return 0;
    }
    for(int i=0;i<n;i++)
    {
        if(isSafe(a,k,i+1))
        {
            a[k]=i+1;
            permutation(n,a,k+1);
        }
    }
    return 0;
}
int main()
{
    int n;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++)
    {
        arr[i]=i+1;
    }
    cout<<"Permutations without repetition: "<<endl;
    permutation(n,arr,0);
    cout<<"Permutations with repetition: "<<endl;
    repeatedPermutation(n,arr,0);
    return 0;
}