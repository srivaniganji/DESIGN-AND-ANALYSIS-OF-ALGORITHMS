#include<iostream>
using namespace std;
int countSubsets(int n,int arr[],int s)
{
    if(n==0)
        return 0;
    if(s==0)
        return 1;
    if(arr[n-1]<=s)
        return countSubsets(n,arr,s-arr[n-1])+countSubsets(n-1,arr,s);
    return countSubsets(n-1,arr,s);
}
int main()
{
    int n;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    int s;
    cin>>s;
    int count=countSubsets(n,arr,s);
    cout<<"Total number of Subsets possible for given sum = "<<count<<endl;
    return 0;
}