#include<iostream>
#include<vector>
using namespace std;
int knapsack(int n,int wt[],int val[],int w,vector<vector<int>>dp)
{
    if(dp[n][w]!=-1)
        return dp[n][w];
    if(n==0 || w==0)
        return dp[n][w]=0;
    if(wt[n-1]<=w)
        return dp[n][w]=max(val[n-1]+knapsack(n-1,wt,val,w-wt[n-1],dp),knapsack(n-1,wt,val,w,dp));
    else 
        return dp[n][w]=knapsack(n-1,wt,val,w,dp);
}
int main(){
    int n;
    cin>>n;
    int wt[n];
    for(int i=0;i<n;i++)
    {
        cin>>wt[i];
    }
    int val[n];
    for(int j=0;j<n;j++)
    {
        cin>>val[j];
    }
    int w;
    cin>>w;
    vector<vector<int>>dp(n+1,vector<int>(w+1,-1));
    int profit=knapsack(n,wt,val,w,dp);
    cout<<"Profit = "<<profit<<endl;
    return 0;
}