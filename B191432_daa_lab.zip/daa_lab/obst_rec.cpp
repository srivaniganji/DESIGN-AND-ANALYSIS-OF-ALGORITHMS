#include<iostream>
#include<climits>
using namespace std;
int sum(int freq[],int i,int j)
{
    int s=0;
    for(int k=i;k<=j;k++)
    {
        s+=freq[k];
    }
    return s;
}
int obst(int i,int j,int keys[],int freq[])
{
    if(j<i)
        return 0;
    if(i==j)
        return freq[i];
    int mini=INT_MAX;
    for(int k=i;k<=j;k++)
    {
        int val=obst(i,k-1,keys,freq)+obst(k+1,j,keys,freq);
        mini=min(mini,val);
    }
    return mini+sum(freq,i,j);
}
int main()
{
    int n;
    cin>>n;
    int keys[n];
    for(int i=0;i<n;i++)
    {
        cin>>keys[i];
    }
    int freq[n];
    for(int i=0;i<n;i++)
    {
        cin>>freq[i];
    }
    cout<<"Optimal cost of retrieving all nodes = "<<obst(0,n-1,keys,freq)<<endl;
}