#include<iostream>
using namespace std;
int totalCoins(int n,int coins[],int s)
{
    if(n==0)
        return 0;
    if(s==0)
        return 1;
    if(coins[n-1]<=s)
        return totalCoins(n,coins,s-coins[n-1])+totalCoins(n-1,coins,s);
    return totalCoins(n-1,coins,s);
}
int main()
{
    int n;
    cin>>n;
    int coins[n];
    for(int i=0;i<n;i++)
    {
        cin>>coins[i];
    }
    int s;
    cin>>s;
    int total_coins=totalCoins(n,coins,s);
    cout<<"Total ways of coin change = "<<total_coins<<endl;
    return 0;
}