#include<iostream>
using namespace std;
int merge(int arr[],int i1,int j1,int i2,int j2)
{
    int i=i1;
    int j=i2;
    int k=0;
    int temp[20];
    while(i<=j1 && j<=j2)
    {
        if(arr[i]<arr[j])
            temp[k++]=arr[i++];
        else 
            temp[k++]=arr[j++];
    }
    while(i<=j1)
        temp[k++]=arr[i++];
    while(j<=j2)
        temp[k++]=arr[j++];
    for(i=i1,j=0;i<=j2;i++,j++)
    {
        arr[i]=temp[j];
    }
    return 0;
}
int mergeSort(int arr[],int s,int e)
{
    if(s<e)
    {
        int mid=(s+e)/2;
        mergeSort(arr,s,mid);
        mergeSort(arr,mid+1,e);
        merge(arr,s,mid,mid+1,e);
    }
}
int main()
{
    int n;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    mergeSort(arr,0,n);
    cout<<"Sorted array: ";
    for(int i=0;i<n;i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
    return 0;
}