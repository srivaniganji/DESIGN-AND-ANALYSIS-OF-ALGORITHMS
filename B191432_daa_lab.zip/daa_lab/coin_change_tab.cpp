#include<iostream>
#include<climits>
#include<vector>
using namespace std;
int minimumCoins(int n,int coins[],int s,vector<vector<int>>dp)
{
    for(int i=0;i<=n;i++)
    {
        for(int j=0;j<=s;j++)
        {
            if(i==0)
            {
                dp[i][j]=INT_MAX;
                continue;
            }
            if(j==0)
            {
                dp[i][j]=1;
                continue;
            }
            if(coins[i-1]<=s)
                dp[i][j]=min(1+dp[i][j-coins[i-1]],dp[i-1][j]);
            else 
                dp[i][j]=dp[i-1][j];
        }
    }
    return dp[n][s];
}
int main()
{
    int n;
    cin>>n;
    int coins[n];
    for(int i=0;i<n;i++)
    {
        cin>>coins[i];
    }
    int s;
    cin>>s;
    vector<vector<int>>dp(n+1,vector<int>(s+1,-1));
    int min_coins=minimumCoins(n,coins,s,dp);
    cout<<"Minimum number of coins required = "<<min_coins<<endl;
    return 0;
}