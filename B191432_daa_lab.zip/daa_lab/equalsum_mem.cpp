#include<iostream>
#include<vector>
using namespace std;
int isSubsetSum(int n,int arr[],int s,vector<vector<int>>dp)
{
    /*
    if(dp[n][s]!=-1)
        return dp[n][s];
    if(n==0)
        return dp[n][s]=0;
    if(s==0)
        return dp[n][s]=1;
    if(arr[n-1]<=s)
        return dp[n][s]=(isSubsetSum(n-1,arr,s-arr[n-1],dp) || isSubsetSum(n-1,arr,s,dp));
    return isSubsetSum(n-1,arr,s,dp);
    */
    if(dp[n][s]!=-1)
        return dp[n][s];
    if(n==0)
        return dp[n][s]=0;
    if(s==0)
        return dp[n][s]=1;
    if(arr[n-1]<=s)
        return dp[n][s]=(isSubsetSum(n-1,arr,s-arr[n-1],dp) || isSubsetSum(n-1,arr,s,dp));
    return dp[n][s]=isSubsetSum(n-1,arr,s,dp);
}
int main()
{
    int n;
    cin>>n;
    int arr[n];
    int sum=0;
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
        sum+=arr[i];
    }
    int flag=-1;
    vector<vector<int>>dp(n+1,vector<int>(sum/2+1,-1));
    if(sum%2!=0)
        flag=0;
    else 
        flag=isSubsetSum(n,arr,sum/2,dp);
    if(flag)
        cout<<"Equal Sum Partition possible!"<<endl;
    else 
        cout<<"Equal Sum Partition not possible!"<<endl;
    return 0;
}