//Subsets are represented in binary format

#include<iostream>
using namespace std;
void checkSum(int n,int arr[],int sum)
{
    int s=0;
    for(int i=0;i<n;i++)
    {
        if(arr[i]==1)
            s+=i+1;
    }
    if(s==sum)
    {
        for(int i=0;i<n;i++)
        {
            cout<<arr[i];
        }
        cout<<endl;
    }
}
void sumOfSubsets(int n,int arr[],int sum,int k)
{
    if(k==n)
    {
        checkSum(n,arr,sum);
        return;
    }
    for(int i=0;i<2;i++)
    {
        arr[k]=i;
        sumOfSubsets(n,arr,sum,k+1);
    }
}
int main()
{
    int n;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++)
    {
        arr[i]=i+1;
    }
    int sum;
    cin>>sum;
    cout<<"Subsets whose sum "<<sum<<" are: "<<endl;
    sumOfSubsets(n,arr,sum,0);
    return 0;
}