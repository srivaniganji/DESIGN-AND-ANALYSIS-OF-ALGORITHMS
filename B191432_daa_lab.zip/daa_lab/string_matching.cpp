#include<iostream>
#include<cstring>
using namespace std;
int main()
{
    string str;
    cin>>str;
    int n=str.size();
    string pattern;
    cin>>pattern;
    int k=pattern.size();
    bool flag;
    for(int i=0;i<n-k+1;i++)
    {
        flag=true;
        for(int j=0;j<k;j++)
        {
            if(pattern[j]!=str[j+i])
            {
                flag=false;
                break;
            }
        }
        if(flag)
        {
            cout<<"Pattern Matching found!"<<endl;
            return 0;
        }
    }
    cout<<"Pattern Matching not found!"<<endl;
}