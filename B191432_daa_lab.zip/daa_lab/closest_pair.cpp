#include<bits/stdc++.h>
#include<math.h>
using namespace std;
struct point
{
    int x;
    int y;
};
int main()
{
    int n;
    cin>>n;
    struct point p1,p2;
    struct point p[n];
    for(int i=0;i<n;i++)
    {
        cin>>p[i].x>>p[i].y;
    }
    double min_dif=INT_MAX;
    for(int i=0;i<n-1;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            double d=sqrt(((p[j].x-p[i].x)*(p[j].x-p[i].x))+((p[j].y-p[i].y)*(p[j].y-p[i].y)));
            if(d<min_dif)
            {
                p1=p[i];
                p2=p[j];
                min_dif=d;
            }
        }
    }
    cout<<"Closest Pair Distance = "<<min_dif<<endl;
    cout<<"Closest Pair of Points are ("<<p1.x<<","<<p1.y<<") and ("<<p2.x<<","<<p2.y<<")"<<endl;
    return 0;
}

/*
6 -> No. of points

2 3
12 30
40 50
5 1
12 10
3 4

Output:   
1.41421
(2,3) and (3,4)
*/